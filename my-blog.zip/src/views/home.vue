<script setup>

</script>

<template>
  <div>主页</div>
</template>