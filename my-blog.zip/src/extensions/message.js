// import Message from "../components/Message.vue"
// declare module 'vue' {
//   interface ComponentCustomProperties {
//     $translate: (key: string) => string
//   }
// }