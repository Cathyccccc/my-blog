export const gradient = ['#55bbff', '#72c7ff', '#8fd2ff', '#acdeff', '#caeaff', '#e7f5ff'];

export const week = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];